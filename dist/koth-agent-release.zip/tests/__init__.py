"""Tests package for koth-agent."""
